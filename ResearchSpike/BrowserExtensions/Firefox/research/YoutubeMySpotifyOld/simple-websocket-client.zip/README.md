# Simple-WebSocket-Client

Simple WebSocket Client is an extension for Google Chrome
to help construct custom Web Socket requests
and handle responses to directly test your Web Socket services.

## Extension URL

https://chrome.google.com/extensions/detail/pfdhoblngboilpfeibdedpjgfnlcodoo

## License

This software is released under the MIT License, see LICENSE.txt.
